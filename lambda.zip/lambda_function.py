import json
import tensorflow as tf
import tensorflow.keras as keras
from keras.datasets import cifar10
import numpy as np
import time

def lambda_handler(event, context):
    startTime=time.time()
    start=event['start']
    end=event['end']
    print(event['weights'])
    print(type(event['weights']))
    if "weights"  in event.keys() and event['weights']!= "0" :
        weights=json.loads(event['weights'])
    else:
        print("override")
        weights=np.load('1_1.npy',allow_pickle=True)
        for i in range(len(weights)):
            weights[i]=np.array(weights[i])
        weights=np.array(weights)
    class_names=['airplane','automobile','bird','cat','deer','dog','frog','horse','ship','truck']
    (x_train,y_train),(x_test,y_test)=cifar10.load_data()
    
    
    np.random.seed(21) 
    np.random.shuffle(x_train)
    np.random.seed(21) 
    np.random.shuffle(y_train)
    
    # # (x_train,y_train),(x_test,y_test)=tfds.load('cifar10', split='train[10:20]')
    x_train=x_train[start:min(end,50000)]
    y_train=y_train[start:min(end,50000)]
    x_train=x_train/255.0
    x_test=x_test/255.0
    
    cifar10_model=keras.models.Sequential()

    # First Layer
    cifar10_model.add(keras.layers.Conv2D(filters=32,kernel_size=3,padding="same", activation="relu", input_shape=[32,32,3]))
    
    # Second Layer
    cifar10_model.add(keras.layers.Conv2D(filters=32,kernel_size=3,padding="same", activation="relu"))
    
    # Max Pooling Layer
    cifar10_model.add(keras.layers.MaxPool2D(pool_size=2,strides=2,padding='valid'))
   
    # Third Layer
    cifar10_model.add(keras.layers.Conv2D(filters=64,kernel_size=3,padding="same", activation="relu"))
    
    # Fourth Layer
    cifar10_model.add(keras.layers.Conv2D(filters=64,kernel_size=3,padding="same", activation="relu"))
    
    # Max Pooling Layer
    cifar10_model.add(keras.layers.MaxPool2D(pool_size=2,strides=2,padding='valid'))
    
    # Flattening Layer
    cifar10_model.add(keras.layers.Flatten())
    
    # Adding the first fully connected layer
    cifar10_model.add(keras.layers.Dense(units=32,activation='relu'))

    # Output Layer
    cifar10_model.add(keras.layers.Dense(units=10,activation='softmax'))
    # cifar10_model.summary()
    cifar10_model.compile(loss="sparse_categorical_crossentropy", optimizer="adam", metrics=["sparse_categorical_accuracy","accuracy"])
    cifar10_model.set_weights(weights)
    
    summary=cifar10_model.fit(x_train,y_train,epochs=1, verbose=0)
    # test_loss, test_accuracy = cifar10_model.evaluate(x_test, y_test)
    # print("Test accuracy: {}".format(test_accuracy))
    weights=cifar10_model.get_weights()
    for i in range(len(weights)):
        weights[i]=weights[i].tolist()
    endTime=time.time()
    
    return {
        'statusCode': 200,
        'body': {
            "time":endTime-startTime,
            'start':start,
            'end': end,
            "summary":summary.history,
            "weights":json.dumps(weights)
        }
    }
